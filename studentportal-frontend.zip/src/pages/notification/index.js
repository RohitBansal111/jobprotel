import Layout from "../../components/Layout"



const Notification = () => {
     return (
          <Layout>
               <div className="inner-page-wrapper">
                    <section className="topbg-banner">
                         <div className="container">
                              <div className="innerbg-banner">
                              </div>
                         </div>
                    </section>
                    <section className="job-feeds-wrapper">
                         <div className="container">
                              <div className="Notification-list text-white">
                                   Notification
                              </div>
                         </div>
                    </section>
               </div>
          </Layout>
     )
}

export default Notification
