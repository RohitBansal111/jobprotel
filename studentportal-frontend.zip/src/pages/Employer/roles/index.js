import Layout from "./../../../components/Layout"

const EmployerRoles = () =>{
     return (
          <Layout>
               <div className="inner-page-wrapper">
                    <section className="topbg-banner">
                         <div className="container">
                              <div className="innerbg-banner">
                              </div>
                         </div>
                    </section>
                    <section className="job-feeds-wrapper">
                         <div className="container">
                              <h3 className="text-white">Roles</h3>
                         </div>
                    </section>
               </div>
          </Layout>
     )
}

export default EmployerRoles
