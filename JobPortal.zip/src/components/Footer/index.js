import React from 'react'

const Footer = () => {
     return (
          <footer className="footer-main">
               <div className="container">
                    <p>© 2021 - 2022 Job Portal® Global Inc.</p>
               </div>  
          </footer>
     )
}

export default Footer
